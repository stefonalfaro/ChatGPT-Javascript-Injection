# ChatGPT-Javascript-Injection
Extends ChatGPT to allow Plugin Development for Private Use Cases
